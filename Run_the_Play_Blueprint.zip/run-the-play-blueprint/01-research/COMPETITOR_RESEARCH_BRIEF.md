# Competitor and Model Research Brief

## Objective

Study products that organize fragmented service, software, podcast, and advertising markets. Identify patterns Run the Play should adopt, adapt, or avoid.

## Primary model: Clutch

Research:

- Profile claim flow
- Profile information architecture
- Category and location pages
- Filters and ranking
- Verification and trust language
- Buyer guides
- Paid placement labeling
- Lead or inquiry flow
- Subscription and premium-profile options
- Internal linking
- Schema and indexation patterns

Key adaptation:

Replace agency services with podcast advertising inventory and make the Ad Planner the first entry point.

## Secondary models

### G2

Study:

- Category education
- Compare and shortlist behavior
- Buyer-intent pages
- Review and trust mechanics

### DesignRush and GoodFirms

Study:

- Claimable profile monetization
- Category-page scale
- Featured-listing presentation
- Risks of thin or repetitive SEO pages

### Crunchbase

Study:

- Structured entity profiles
- Relationship modeling
- Data freshness
- Free vs. paid data access

### Product Hunt

Study:

- Freshness
- Featured launches
- Community discovery

### Listen Notes and Podchaser

Study:

- Podcast identity and metadata
- Search and discovery
- Show and episode relationships
- Claim and creator tools

### Rephonic and podcast intelligence tools

Study:

- Audience presentation
- Cross-platform metrics
- Data-source explanations
- Comparison and campaign research workflows

### Podcast ad marketplaces

Study only for inventory language and buyer workflow. Run the Play should deliberately avoid brokerage, checkout, and commission mechanics under the current thesis.

## Research template for each competitor

- Product description
- Primary customer
- Core job to be done
- Entry point
- Search and filters
- Profile anatomy
- Trust signals
- Buyer workflow
- Provider workflow
- Monetization
- SEO architecture
- Content strategy
- Strengths
- Weaknesses
- Patterns to adopt
- Patterns to avoid
- Screenshots and notes

## Key research questions

1. What makes a provider claim a profile?
2. What makes a buyer create an account?
3. How is paid visibility separated from organic relevance?
4. How are incomplete profiles handled?
5. How are comparisons presented?
6. Which pages generate search traffic?
7. What data creates trust?
8. How is freshness communicated?
9. How does the product prevent directory pages from feeling empty?
10. What workflow can be simplified for a first-time buyer?
