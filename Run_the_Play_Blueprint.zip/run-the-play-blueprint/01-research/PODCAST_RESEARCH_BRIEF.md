# Podcast Research Brief

## Objective

Build a reliable seed list of hip-hop podcasts and a repeatable process for expanding, verifying, and refreshing the database.

The first milestone is not “the largest list.” It is a useful, trustworthy list with enough structured information to power the Ad Planner.

## Initial target

Create a curated seed database of **100 to 250 active hip-hop and adjacent culture podcasts**.

The initial list should include a balanced mix of:

- Independent shows
- Network shows
- Audio-first shows
- Video-first shows
- National and regional shows
- Large, mid-sized, and emerging shows
- Music, culture, business, sports, fashion, and creator-adjacent audiences

## Inclusion criteria

A podcast can be included when:

- It has a clear hip-hop, music, Black culture, or closely adjacent audience.
- It has published within the selected activity window, recommended initial window: 120 days.
- It has an identifiable official page, RSS feed, platform profile, or website.
- It has enough public information to create a non-misleading basic profile.

## Exclusion or hold criteria

- Inactive or ended shows without clear archival value
- Duplicate feeds
- Clip channels that are not podcasts
- Unofficial repost channels
- Profiles with unresolved identity conflicts
- Shows whose inclusion would create legal or safety concerns

## Research questions

For each podcast, determine:

1. Is the show active?
2. What is the official title and artwork?
3. Who hosts or produces it?
4. Is it independent or part of a network?
5. What are its primary topics?
6. Who does it appear to reach?
7. Which audience claims are explicitly supported?
8. Does it offer advertising or sponsorship?
9. Which inventory formats are publicly stated?
10. Is pricing public, private, or unavailable?
11. What is the preferred advertising contact path?
12. Is there a public media kit?
13. When was the information last confirmed?

## Recommended source hierarchy

Use the strongest available source and record where every important field came from.

### Tier 1: Owner-controlled sources

- Official podcast website
- Official RSS feed
- Official media kit
- Official network page
- Official advertising or contact page
- Official social profiles

### Tier 2: Major distribution platforms

- Apple Podcasts
- Spotify
- YouTube
- Amazon Music or Audible
- iHeart
- Other official platform pages

### Tier 3: Podcast databases and industry directories

Use for discovery and cross-checking, not as the only authority for sensitive claims.

- Podcast Index
- Listen Notes
- Podchaser
- Rephonic
- Podnews directory and network reporting
- Other reputable podcast intelligence products

### Tier 4: Press and public reporting

- Interviews
- Trade publications
- Network announcements
- Sponsor case studies

## Research workflow

### Stage 1: Discovery

Build candidate lists from:

- Searches for top and emerging hip-hop podcasts
- Podcast-network show rosters
- YouTube podcast and interview channels
- Apple and Spotify categories
- Guest appearances and show recommendations
- Industry articles and awards
- Social conversations and podcast charts

### Stage 2: Identity verification

Confirm:

- Official name
- Official artwork
- RSS or official platform identity
- Host names
- Network relationship
- Official links

### Stage 3: Activity verification

Record:

- Most recent episode date
- Typical publishing frequency
- Whether the show is seasonal or irregular

### Stage 4: Audience classification

Use explicit evidence where available:

- Media-kit demographics
- Official positioning
- Repeated subject matter
- Guest profile
- Geography
- Platform behavior

Do not infer sensitive demographic traits about individual listeners. Audience labels should describe the show’s public positioning and reported audience, not make unsupported claims about people.

### Stage 5: Advertising research

Look for:

- Sponsor pages
- “Advertise with us” pages
- Network sales pages
- Media kits
- Rate cards
- Host-read references
- Video sponsorship disclosures
- Newsletter or event offerings
- Direct advertising contact

### Stage 6: Data-quality review

Each record receives:

- Completeness score
- Freshness date
- Confidence level
- Claimability status
- Duplicate check
- Researcher notes

## Minimum viable profile fields

Required:

- Podcast name
- Slug
- Short description
- Artwork
- Official URL or platform URL
- Primary category
- Active/inactive status
- Most recent episode date
- Host or network when available
- At least one contact or official destination link
- Source records
- Last researched date

Preferred:

- RSS feed
- Geography
- Audience tags
- Platforms
- Publishing frequency
- Advertising availability
- Inventory formats
- Price state
- Media kit

## Advertising data rules

### Public price

Store the exact public price, source URL, currency, billing unit, and date checked.

### Starting price or range

Store exactly as stated. Do not convert a starting price into a fixed price.

### Contact for pricing

Use this when the podcast indicates advertising is available but does not publish a rate.

### Unknown

Use this when no reliable advertising information is available.

### Estimated

Avoid estimating podcast ad prices in the seed database. If estimates are introduced later, keep them clearly separated from owner-provided or public prices and publish the methodology.

## Data confidence labels

- **Verified:** Confirmed directly by the owner or through strong verification.
- **Owner provided:** Submitted by a claimed profile owner but not independently audited.
- **Public source:** Found on an official public source.
- **Cross-checked:** Supported by more than one credible source.
- **Inferred:** Reasonable category or audience classification based on public content.
- **Unknown:** Not enough evidence.

## Research team instructions

- Never fabricate a missing field.
- Save the source URL for every important claim.
- Use neutral descriptions.
- Avoid copying long descriptions from websites or platforms.
- Mark unclear network relationships for review.
- Record the date of every check.
- Flag duplicate feeds and renamed shows.
- Respect platform terms and rate limits.
- Do not collect private personal information.

## Refresh cadence

- Inventory and pricing: every 30 to 60 days
- Activity status: every 30 days
- Audience metrics: every 60 to 90 days
- Identity fields: when a change is detected
- Claimed profiles: prompt owners to reconfirm inventory regularly

## Suggested research batches

### Batch 1: Anchor shows

25 highly recognizable shows to define the taxonomy and profile standard.

### Batch 2: Networks

Research complete rosters for relevant podcast networks.

### Batch 3: Independent video podcasts

Focus on YouTube-first and studio-based shows.

### Batch 4: Regional shows

Build coverage for Atlanta, New York, Los Angeles, DMV, Chicago, Houston, Memphis, Detroit, Miami, and other major markets.

### Batch 5: Emerging shows

Add smaller active podcasts with clear audiences and accessible operators.

## Deliverables

1. Master podcast research spreadsheet
2. Source log
3. Duplicate report
4. Missing-data report
5. Taxonomy recommendations
6. Network roster report
7. Advertising availability report
8. List of priority profiles to invite for claiming

## Success criteria

A seed list is launch-ready when:

- Records are active and deduplicated.
- Required fields are at least 95% complete.
- Every record has source evidence.
- At least 25% include known advertising availability.
- The list supports useful planner results across several budgets, audiences, formats, and geographies.
