# MVP Backlog

## Epic: Seed data

- Define import CSV
- Build podcast importer
- Add duplicate detection
- Add source records
- Add freshness dates
- Create admin review queue

## Epic: Profiles

- Public profile route
- Profile sections
- Claim CTA
- Similar podcast module
- Source labels
- Noindex rules for incomplete profiles

## Epic: Claims

- Claim form
- Verification methods
- Admin review
- Role-based access
- Dispute process

## Epic: Inventory

- Inventory CRUD
- Price types
- Availability
- Media kit
- Freshness reminder

## Epic: Planner

- Campaign goal
- Budget
- Audience
- Geography
- Formats
- Dates
- Match scoring
- Explanations
- Empty state

## Epic: Basket

- Add/remove
- Quantity
- Budget meter
- Notes
- Save
- Share
- Export
- Direct contact

## Epic: Billing

- Plans
- Checkout
- Webhooks
- Billing portal
- Entitlements

## Epic: Content

- CMS
- Guides
- Category pages
- Internal links
- Schema
- Sitemap and robots controls

## Epic: Quality

- Accessibility
- Analytics
- Error monitoring
- Automated tests
- Security review
