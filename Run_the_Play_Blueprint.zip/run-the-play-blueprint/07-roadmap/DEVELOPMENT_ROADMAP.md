# Development Roadmap

## Product approach

Build the smallest complete planning loop first:

**Plan -> Match -> Basket -> Save or Share -> Direct Contact**

Do not begin with a giant directory or a complicated AI system.

## Phase 0: Validation and research

### Outcomes

- Validate buyer workflow
- Validate podcast-owner willingness to claim and pay
- Build initial taxonomy
- Create seed database
- Test planner recommendations manually

### Work

- Interview 10 to 15 potential buyers
- Interview 10 to 15 podcast operators
- Research 100 to 250 podcasts
- Create 10 example campaign plans manually
- Test $10 and $20 subscription positioning
- Define verification and data-source policy
- Prototype homepage and planner

### Exit criteria

- Clear planner questions
- At least three recurring buyer use cases
- At least 10 podcast owners willing to claim or test
- Seed data supports useful recommendations

## Phase 1: Foundation and public profiles

### Product

- Application shell
- Authentication
- Public podcast profiles
- Directory search and basic filters
- Admin import and editing
- Taxonomy
- Source records and freshness labels
- Claim request workflow

### Content

- Homepage
- Claim page
- Pricing page
- Methodology page
- Initial buyer guides

### Exit criteria

- 100 quality profiles live
- Claims can be reviewed safely
- Profile data can be updated without developer work

## Phase 2: Inventory and subscriptions

### Product

- Podcast dashboard
- Profile editor
- Inventory manager
- Media-kit upload or link
- Stripe plans
- Billing portal
- Basic profile analytics

### Exit criteria

- Claimed podcast can publish inventory independently
- Subscription lifecycle works
- Stale inventory can be flagged

## Phase 3: Ad Planner MVP

### Product

- Multi-step planner
- Rules-based match scoring
- Recommendation explanations
- Guest session
- Account save
- No-result recovery
- Analytics events

### Exit criteria

- Users can complete a plan on mobile and desktop
- Recommendations are reproducible and explainable
- No unsupported metrics are generated

## Phase 4: Campaign Basket

### Product

- Add and remove opportunities
- Budget calculations
- Known/starting/estimated/unknown price states
- Notes
- Reordering
- Save and duplicate
- Read-only share link
- PDF and CSV export
- Direct-contact actions

### Exit criteria

- Complete Plan -> Basket -> Share/Export/Contact loop works
- Shared plans protect private information

## Phase 5: Content and SEO engine

### Product and content

- Category templates
- Audience and inventory-format pages
- Quality thresholds and index controls
- Internal-link modules
- Structured data
- Editorial workflow

### Exit criteria

- No thin pages are automatically indexed
- Pages route users into the planner
- Reporting measures planner actions from organic traffic

## Phase 6: Optimization

- Saved searches
- Inventory alerts
- Better recommendation weighting
- Network accounts
- Collaboration and comments
- Bulk podcast management
- Freshness reminders
- Data-quality scoring
- Search-service evaluation

## Phase 7: Advanced intelligence

Only after enough real usage data exists:

- Natural-language campaign brief
- AI-assisted audience tagging with human review
- Similar-podcast modeling
- Basket optimization under budget constraints
- Audience-overlap visualization where supported by legitimate data

## Priority backlog

### Must have

- Seed database
- Profiles
- Claims
- Inventory
- Planner
- Basket
- Direct contact
- Subscription billing
- Source and freshness labels

### Should have

- Exports
- Sharing
- Basic analytics
- Editorial CMS
- Category pages
- Media kits

### Could have

- Saved search alerts
- Team collaboration
- Network dashboards
- Advanced comparisons
- Recommendation feedback

### Not now

- Marketplace checkout
- Commission billing
- Public reviews
- Automated contracts
- Ad serving
- Guaranteed reach forecasts

## Milestone sequence

1. Research-ready data model
2. Admin seed-data workflow
3. Public profile alpha
4. Claim and inventory beta
5. Planner private beta
6. Basket beta
7. Public launch
8. SEO expansion after data-quality review
