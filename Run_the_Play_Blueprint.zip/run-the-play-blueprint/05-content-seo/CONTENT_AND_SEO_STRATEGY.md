# Content and SEO Strategy

## Objective

Use structured podcast data, buyer education, and useful planning tools to make Run the Play discoverable when people research podcast advertising, culturally relevant media, and specific audience opportunities.

SEO supports the product. It should not create thousands of thin pages before the underlying data is useful.

## Content architecture

### 1. Podcast profiles

Intent:

- Brand searches
- Podcast name searches
- Podcast advertising searches
- Host and network searches

Profile title pattern:

`[Podcast Name] Advertising, Audience and Sponsorship Opportunities`

Profile content:

- Original summary
- Audience and topic fit
- Available inventory
- Price state
- Platforms
- Contact path
- Data source and freshness
- Similar podcasts

Avoid copying podcast descriptions verbatim at scale.

### 2. Category pages

Examples:

- Hip-Hop Podcasts Open to Advertising
- Independent Hip-Hop Podcasts
- Video Hip-Hop Podcasts
- Music Business Podcasts
- Hip-Hop Interview Podcasts
- Podcasts for Sneaker and Fashion Brands
- Podcasts Reaching Independent Artists

Each indexable category page needs:

- A clear search intent
- A useful introduction
- Enough qualified profiles
- Unique editorial guidance
- Relevant filters
- Frequently asked questions based on real buyer needs
- Links to the Ad Planner and buyer guides

### 3. Audience pages

Examples:

- Podcasts Reaching Gen Z Hip-Hop Fans
- Podcasts for Music Industry Professionals
- Podcasts Reaching Entrepreneurs
- Podcasts for DMV Audiences

Only publish an audience page when the supporting data has a clear methodology and sufficient coverage.

### 4. Inventory-format pages

Examples:

- Hip-Hop Podcasts Offering Host-Read Ads
- Podcasts Offering Video Integrations
- Podcasts Offering Sponsored Interviews
- Podcast Newsletter Sponsorship Opportunities

### 5. Buyer guides

Priority guides:

1. How to Build a Podcast Advertising Plan
2. How Much Does Podcast Advertising Cost?
3. Host-Read Ads Explained
4. Podcast Advertising for Independent Artists
5. Podcast Advertising for Events
6. How to Choose a Podcast Audience
7. How to Read a Podcast Media Kit
8. Podcast Ads vs. Social Media Ads
9. Questions to Ask Before Sponsoring a Podcast
10. How to Track a Podcast Campaign

Every guide should route the reader into the Ad Planner with a relevant preselected goal or format.

### 6. Research and reports

- State of Hip-Hop Podcast Advertising
- Common Inventory Formats Across Hip-Hop Podcasts
- Published Rate and Pricing Methodology Report
- Audience and Platform Trends

Reports should explain data limits and distinguish public, self-reported, verified, and estimated information.

## Programmatic SEO rules

Do not launch pages based on every possible combination.

A landing page becomes indexable only when it passes minimum quality thresholds such as:

- At least 8 relevant active podcast profiles
- At least 60% of profiles updated within the freshness window
- Unique introduction and decision guidance
- No duplicate or near-duplicate intent
- A clear internal-linking role
- Meaningful planner integration

Otherwise, use `noindex` or keep the filter view dynamic.

## Taxonomy

Primary facets:

- Podcast topic
- Audience interest
- Audience age
- Geography
- Ad format
- Price range
- Video or audio
- Independent or network
- Campaign goal

Keep labels understandable. Do not create categories solely because a keyword tool shows volume.

## Internal linking

### Profiles link to

- Relevant categories
- Audience pages
- Inventory-format pages
- Related podcasts
- Relevant buyer guides
- Ad Planner with profile preselected

### Category pages link to

- Featured profiles
- Adjacent categories
- Relevant buyer guides
- Planner with category criteria preselected

### Guides link to

- Relevant profiles and categories
- Definitions
- Planner step matching the guide intent

### Planner results link to

- Full profiles
- Methodology
- Relevant education explaining pricing or inventory formats

## Structured data

Use only schema types that truthfully describe the page.

Potential types:

- `PodcastSeries` for a podcast profile
- `Person` for hosts
- `Organization` for networks and managing companies
- `Article` for guides and reports
- `BreadcrumbList`
- `FAQPage` only when visible FAQs meet search-engine rules
- `ItemList` for editorial category lists when appropriate

Do not mark inventory pricing as an ecommerce `Offer` unless the product can actually be purchased under those exact terms. Since Run the Play does not sell the ad, structured pricing must not imply checkout or guaranteed availability.

## On-page profile template

- H1: Podcast name
- One-sentence positioning
- Claim and verification status
- Audience fit
- Advertising opportunities
- Price status
- Platforms
- Media kit
- Contact route
- Source and update methodology
- Similar shows
- Planner CTA

## Editorial standards

- Original writing
- Clear sourcing
- No fabricated metrics
- No copied media-kit claims without attribution
- Separate facts from estimates
- Date-stamp meaningful data
- Allow podcast owners to correct information
- Explain ranking and featured-placement policy

## Ranking policy

Organic directory ranking should be driven by relevance and data quality.

Potential paid placement:

- Must be labeled “Sponsored” or “Featured.”
- Must not falsely imply editorial endorsement.
- Must not silently override planner matching.

## Measurement

- Organic profile visits
- Non-brand organic visits
- Planner starts from organic pages
- Planner completion by landing-page type
- Basket adds from profiles
- Direct-contact actions
- Indexed pages passing quality thresholds
- Freshness and content-update coverage
