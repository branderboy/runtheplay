# Product Thesis

## The thesis

Hip-hop podcasts have valuable audiences and advertising opportunities, but the information buyers need is fragmented across websites, social profiles, media kits, direct messages, and private conversations. The industry lacks a simple, culture-first place where someone can identify the audience they want, enter a budget, discover relevant shows, and organize a realistic advertising plan.

Run the Play should exist to make that discovery and planning process simple.

## The problem

Podcast owners often have no structured place to show:

- Who their audience is
- What inventory is available
- Which formats they support
- What campaigns are a good fit
- How buyers should contact them

Buyers face a different set of problems:

- They do not know which shows fit their audience.
- They cannot compare opportunities consistently.
- They do not know what can fit within their budget.
- They have to search across disconnected platforms.
- Small buyers may not understand podcast advertising terminology.

## The solution

Run the Play combines four products:

1. A Clutch-style directory of claimable podcast profiles
2. Structured advertising inventory
3. An Ad Planner that begins with the buyer's goal, budget, and audience
4. A Campaign Basket that organizes the selected opportunities

## What Run the Play is

- A discovery platform
- A planning tool
- A publishing platform
- A structured database of hip-hop podcast advertising opportunities
- A direct bridge between an interested buyer and a podcast's preferred contact method

## What Run the Play is not

- An advertising agency
- A media buyer
- A broker
- A payment processor for ad deals
- A representative of the listed podcasts
- A guarantee of audience size, results, pricing, or availability

## Primary entry point

The Ad Planner is the front door.

The directory supports the planner. Profiles and inventory provide the data used to create recommendations. Users who prefer to browse can still explore the directory directly.

## Core promise

> Tell us who you want to reach, what you want to accomplish, and what you can spend. Run the Play will help you organize the right podcast advertising opportunities.

## Positioning

**Run the Play**  
**Advertising Made Simple for the Culture**

## Primary users

### Buyers

- Brands
- Agencies
- Artists and labels
- Entrepreneurs
- Event promoters
- Local businesses
- Nonprofits
- Political and advocacy organizations, subject to platform rules
- Everyday people seeking to scale a message

### Podcast operators

- Independent podcast owners
- Podcast networks
- Producers
- Sales representatives
- Media companies

## Business model

The initial business model is a low-cost podcast subscription:

### Free profile

A basic public listing created from verified public information.

### Claimed profile: target $10 per month

- Claim and verify ownership
- Update profile information
- Add contact links
- Add audience information
- Add platforms and categories

### Inventory profile: target $20 per month

- Add and update advertising inventory
- Add starting prices or “contact for pricing”
- Add availability and campaign fit
- Upload a media kit
- View basic profile and inquiry analytics

Pricing must be validated before launch.

## Product principles

1. Start with the buyer's problem, not the database.
2. Keep direct contact between buyer and podcast.
3. Make inventory understandable to first-time buyers.
4. Clearly separate verified data, self-reported data, and estimates.
5. Build trust through freshness, ownership verification, and transparent methodology.
6. Avoid fake precision when reach or pricing data is incomplete.
7. Make the product useful before requiring an account.

## Why this can compound

- Every claimed profile improves the database.
- Every inventory update improves planner recommendations.
- Every category page improves discovery.
- Every buyer guide educates a new market.
- Every saved campaign reveals demand patterns.
- Better data attracts more podcasts, and more podcasts improve the buyer experience.

## North-star metric

**Completed qualified ad plans per month**

A qualified plan should contain:

- A defined goal
- A defined budget
- A defined audience
- At least three relevant opportunities, when available
- At least one save, share, export, or direct-contact action

## Key supporting metrics

- Planner completion rate
- Basket creation rate
- Direct-contact click rate
- Claimed podcast profiles
- Profiles with current inventory
- Inventory freshness
- Returning buyers
- Organic traffic to profiles, categories, and guides
- Free-to-paid podcast conversion
- Monthly subscription retention

## Long-term vision

Run the Play becomes the default planning layer for culturally relevant podcast advertising: the place where a buyer begins before contacting a show, and the place where a podcast keeps its advertising opportunity visible and current.
