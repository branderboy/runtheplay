# Design Brief

## Design objective

Create a product that feels like a serious planning and discovery platform, not a generic podcast directory and not an ad agency website.

The experience should make first-time buyers feel guided while giving experienced buyers enough structure and control to move quickly.

## Primary inspiration

### Clutch

Borrow:

- Claimable profiles
- Structured service and pricing information
- Strong category architecture
- Buyer education
- Comparison-oriented discovery
- Trust and verification signals

Do not copy:

- Dense agency-directory visual clutter
- Pay-to-rank ambiguity
- Review-heavy product decisions before the platform has enough trust

## Secondary inspiration

### G2

- Clear comparison patterns
- Category education
- Saved shortlists

### Crunchbase

- Structured profile data
- Consistent information hierarchy

### Linear and Stripe

- Clean product interface
- Strong spacing
- Focused forms
- Calm dashboards

## Brand personality

- Culture-first
- Confident
- Useful
- Editorial
- Modern
- Direct
- Credible
- Not corporate or overly technical

## Brand language

Use plain language:

- “Build your ad plan”
- “Who are you trying to reach?”
- “What can you spend?”
- “Add to your plan”
- “Contact the podcast”

Avoid unnecessary ad-tech language.

## Homepage hierarchy

### Hero

**Build Your Podcast Advertising Plan**

Tell us your goal, audience, and budget. Run the Play will help you organize relevant hip-hop podcast opportunities.

Primary CTA: **Start Planning**

Secondary CTA: **Explore Podcasts**

### Supporting sections

1. How the planner works
2. Browse by audience
3. Browse by campaign goal
4. Featured and recently updated podcasts
5. Example campaign baskets
6. Podcast-owner claim CTA
7. Buyer guides
8. Trust and methodology

## Primary navigation

- Ad Planner
- Explore Podcasts
- Audiences
- Guides
- Claim Your Profile
- Pricing
- Sign In

## Ad Planner UX

### Desktop

- Focused centered step form
- Persistent progress indicator
- Optional summary rail showing current selections
- Back and continue controls
- Clear examples under complex fields

### Mobile

- One decision group per screen
- Large tap targets
- Sticky continue button
- Minimal typing
- Save progress after account creation

## Recommendation results

Use cards that prioritize decision-making:

- Name and artwork
- Strong match reason
- Audience tags
- Inventory options
- Price state
- Data freshness
- Add to Basket

Do not overload cards with every profile field.

## Campaign Basket UX

The basket should resemble a lightweight media plan, not an e-commerce cart.

Include:

- Campaign summary
- Budget meter
- Planned spend
- Remaining budget
- Opportunity rows
- Price-status labels
- Notes
- Share and export controls
- Direct-contact actions

Do not use checkout language.

## Podcast profile UX

Profile order:

1. Identity and positioning
2. Audience fit
3. Advertising opportunities
4. Platforms and reach indicators
5. Media kit and contact
6. Recent content
7. Similar podcasts

Primary CTA: **Add to Plan**

Secondary CTA: **Contact Podcast**

For unclaimed profiles, display **Claim this profile** clearly without implying the listing is inaccurate.

## Visual direction

- Generous whitespace
- Strong typographic hierarchy
- Neutral interface surfaces
- Editorial artwork and podcast imagery
- Compact chips for audience and inventory tags
- Tables only when comparison benefits from them
- Avoid oversized gradients, glass effects, and generic SaaS illustrations

## Accessibility

- WCAG 2.2 AA target
- Keyboard-operable planner
- Visible focus states
- Proper form labels and error summaries
- Sufficient contrast
- Text alternatives for podcast artwork
- Do not rely on color alone for verification or price states

## Responsive priorities

1. Planner completion
2. Basket editing
3. Profile readability
4. Search and filtering
5. Owner inventory updates

## Trust design

Display:

- Claimed status
- Verification status
- Data source
- Last updated date
- Price type
- Inventory availability

Sponsored or featured placement must be labeled visibly.
