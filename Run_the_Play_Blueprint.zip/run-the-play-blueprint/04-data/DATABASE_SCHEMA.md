# Database Schema

## Recommended database

PostgreSQL on Neon with Drizzle ORM.

Use UUID primary keys, `created_at`, `updated_at`, and soft deletion where auditability matters.

## Relationship overview

- A user can belong to multiple organizations.
- An organization can manage multiple podcasts.
- A podcast can have multiple hosts, platforms, categories, audience tags, contacts, claims, inventory items, and metrics.
- A buyer can create multiple campaign plans.
- A campaign plan has one Campaign Basket.
- A basket contains multiple selected opportunities.
- A selected opportunity references a podcast and, optionally, a specific inventory item.

## Identity and access

### users

| Field | Type | Notes |
|---|---|---|
| id | uuid | Primary key |
| auth_provider_id | text | Unique |
| email | citext | Unique when present |
| display_name | text | |
| avatar_url | text | |
| status | enum | active, suspended, deleted |
| created_at | timestamptz | |
| updated_at | timestamptz | |

### organizations

| Field | Type | Notes |
|---|---|---|
| id | uuid | Primary key |
| name | text | |
| slug | citext | Unique |
| type | enum | podcast, network, agency, brand, other |
| website_url | text | |
| created_at | timestamptz | |
| updated_at | timestamptz | |

### organization_members

| Field | Type | Notes |
|---|---|---|
| organization_id | uuid | FK organizations |
| user_id | uuid | FK users |
| role | enum | owner, admin, editor, viewer, billing |
| created_at | timestamptz | |

Unique: `(organization_id, user_id)`

## Podcast entities

### podcasts

| Field | Type | Notes |
|---|---|---|
| id | uuid | Primary key |
| organization_id | uuid | Nullable managing organization |
| name | text | |
| slug | citext | Unique |
| short_description | text | |
| full_description | text | |
| artwork_url | text | |
| website_url | text | |
| rss_url | text | Sensitive changes moderated |
| launch_year | integer | |
| status | enum | active, inactive, archived |
| ownership_status | enum | unclaimed, pending, claimed |
| verification_status | enum | unverified, verified, disputed |
| primary_language | text | |
| country_code | char(2) | |
| region | text | |
| city | text | |
| publishing_frequency | enum | daily, weekly, biweekly, monthly, seasonal, irregular |
| average_episode_minutes | integer | |
| data_freshness_at | timestamptz | |
| created_at | timestamptz | |
| updated_at | timestamptz | |
| deleted_at | timestamptz | Nullable |

Indexes:

- unique slug
- name trigram
- ownership status
- verification status
- geography
- freshness

### hosts

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| name | text | |
| slug | citext | Unique |
| bio | text | |
| image_url | text | |
| website_url | text | |

### podcast_hosts

| Field | Type | Notes |
|---|---|---|
| podcast_id | uuid | |
| host_id | uuid | |
| role | text | host, co-host, producer |
| display_order | integer | |

### networks

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| name | text | |
| slug | citext | Unique |
| website_url | text | |

### podcast_networks

| Field | Type | Notes |
|---|---|---|
| podcast_id | uuid | |
| network_id | uuid | |
| relationship_type | enum | owned, distributed, affiliated |
| start_date | date | Nullable |
| end_date | date | Nullable |

### platforms

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| name | text | Apple Podcasts, Spotify, YouTube, etc. |
| platform_type | enum | audio, video, social, newsletter, web |

### podcast_platforms

| Field | Type | Notes |
|---|---|---|
| podcast_id | uuid | |
| platform_id | uuid | |
| profile_url | text | |
| external_id | text | |
| follower_count | bigint | Nullable |
| average_views | bigint | Nullable |
| metric_source | enum | public, owner_reported, verified, estimated |
| metric_updated_at | timestamptz | Nullable |

## Taxonomy

### categories

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| parent_id | uuid | Self-reference, nullable |
| name | text | |
| slug | citext | Unique |
| description | text | |
| indexable | boolean | SEO control |

### podcast_categories

`podcast_id`, `category_id`, `is_primary`

### audience_tags

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| group_name | text | interest, age, profession, culture, life stage |
| name | text | |
| slug | citext | Unique |

### podcast_audience_tags

| Field | Type | Notes |
|---|---|---|
| podcast_id | uuid | |
| audience_tag_id | uuid | |
| confidence | numeric | 0 to 1, nullable |
| source_type | enum | owner_reported, public, verified, inferred |
| source_id | uuid | Nullable |

## Audience data

### audience_snapshots

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | |
| period_start | date | Nullable |
| period_end | date | Nullable |
| average_downloads | bigint | Nullable |
| monthly_listeners | bigint | Nullable |
| average_video_views | bigint | Nullable |
| estimated_reach | bigint | Nullable |
| source_type | enum | owner_reported, public, verified, estimated |
| source_url | text | Nullable |
| verified_at | timestamptz | Nullable |
| created_at | timestamptz | |

### audience_demographics

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| audience_snapshot_id | uuid | |
| dimension | enum | age, gender, geography, interest, other |
| label | text | |
| percentage | numeric | Nullable |
| source_type | enum | owner_reported, public, verified, estimated |

## Advertising inventory

### inventory_types

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| name | text | Host Read, Mid-roll, Sponsored Segment, etc. |
| slug | citext | Unique |
| channel | enum | audio, video, social, newsletter, live, other |
| description | text | |

### inventory_items

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | |
| inventory_type_id | uuid | |
| name | text | |
| description | text | |
| status | enum | active, paused, unavailable, archived |
| price_type | enum | fixed, starting_at, range, contact, unavailable |
| price_amount | numeric | Nullable |
| price_min | numeric | Nullable |
| price_max | numeric | Nullable |
| currency | char(3) | |
| billing_unit | text | episode, week, package, clip, event |
| minimum_quantity | integer | Nullable |
| lead_time_days | integer | Nullable |
| availability_start | date | Nullable |
| availability_end | date | Nullable |
| creative_requirements | text | |
| restrictions | text | |
| destination_url | text | Direct contact or inquiry URL |
| last_confirmed_at | timestamptz | |
| created_at | timestamptz | |
| updated_at | timestamptz | |

Index active inventory by podcast, type, price, and freshness.

### media_kits

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | |
| title | text | |
| file_url | text | Nullable |
| external_url | text | Nullable |
| visibility | enum | public, account_required, private |
| updated_at | timestamptz | |

## Claims and verification

### profile_claims

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | |
| claimant_user_id | uuid | |
| claimant_organization_id | uuid | Nullable |
| role_description | text | |
| method | enum | domain_email, rss, website, social, documents, manual |
| status | enum | draft, pending, approved, rejected, more_info, disputed |
| evidence_json | jsonb | |
| reviewer_user_id | uuid | Nullable |
| reviewed_at | timestamptz | Nullable |
| created_at | timestamptz | |

### source_records

Tracks where profile information came from.

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | Nullable |
| source_type | enum | rss, website, platform, media_kit, owner, manual, api |
| source_url | text | Nullable |
| retrieved_at | timestamptz | |
| raw_data | jsonb | Nullable |
| checksum | text | Nullable |

## Planning

### campaign_plans

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | Nullable for temporary guest sessions |
| name | text | |
| organization_name | text | Nullable |
| goal | enum | |
| message_summary | text | Nullable |
| budget_min | numeric | Nullable |
| budget_max | numeric | |
| currency | char(3) | |
| start_date | date | Nullable |
| end_date | date | Nullable |
| geography_json | jsonb | |
| audience_json | jsonb | |
| format_preferences_json | jsonb | |
| status | enum | draft, active, archived |
| created_at | timestamptz | |
| updated_at | timestamptz | |

### campaign_baskets

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| campaign_plan_id | uuid | Unique |
| share_token_hash | text | Nullable |
| sharing_enabled | boolean | |
| show_notes_on_share | boolean | |
| created_at | timestamptz | |
| updated_at | timestamptz | |

### basket_items

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| basket_id | uuid | |
| podcast_id | uuid | |
| inventory_item_id | uuid | Nullable |
| quantity | integer | Default 1 |
| price_basis | enum | listed, starting, user_estimate, unknown |
| planned_unit_price | numeric | Nullable |
| notes | text | Nullable |
| display_order | integer | |
| match_score | numeric | Nullable |
| match_reasons | jsonb | |
| created_at | timestamptz | |

Unique suggestion: `(basket_id, podcast_id, inventory_item_id)` where supported.

### recommendation_runs

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| campaign_plan_id | uuid | |
| algorithm_version | text | |
| input_snapshot | jsonb | |
| generated_at | timestamptz | |

### recommendation_results

| Field | Type | Notes |
|---|---|---|
| recommendation_run_id | uuid | |
| podcast_id | uuid | |
| inventory_item_id | uuid | Nullable |
| score | numeric | |
| reasons | jsonb | |
| rank | integer | |

## Contacts and activity

### contact_methods

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| podcast_id | uuid | |
| type | enum | email, form, website, social, phone |
| label | text | |
| value_encrypted | text | Use when not public |
| public_url | text | Nullable |
| is_primary | boolean | |

### outbound_actions

Track aggregate intent without pretending a deal occurred.

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| user_id | uuid | Nullable |
| campaign_plan_id | uuid | Nullable |
| podcast_id | uuid | |
| inventory_item_id | uuid | Nullable |
| action_type | enum | contact_click, media_kit_click, website_click, share, export |
| created_at | timestamptz | |

## Billing

### subscriptions

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| organization_id | uuid | |
| provider_customer_id | text | |
| provider_subscription_id | text | Unique |
| plan | enum | claimed, inventory, network |
| status | enum | trialing, active, past_due, canceled, unpaid |
| current_period_end | timestamptz | |
| created_at | timestamptz | |
| updated_at | timestamptz | |

## Content and SEO

### articles

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| title | text | |
| slug | citext | Unique |
| excerpt | text | |
| body | jsonb or text | Depends on CMS |
| content_type | enum | guide, report, editorial, methodology |
| status | enum | draft, published, archived |
| published_at | timestamptz | Nullable |

### landing_pages

| Field | Type | Notes |
|---|---|---|
| id | uuid | |
| page_type | enum | category, audience, geography, format, goal |
| slug | citext | Unique |
| title | text | |
| intro | text | |
| filter_definition | jsonb | |
| index_status | enum | noindex, index |
| quality_score | numeric | |
| updated_at | timestamptz | |

## Audit and moderation

### audit_logs

- actor_user_id
- action
- entity_type
- entity_id
- before_json
- after_json
- created_at

### moderation_flags

- entity_type
- entity_id
- reason
- status
- created_by
- reviewed_by
- timestamps

## Security and permissions

- Use organization-level row access checks.
- Only approved claimants can edit podcast-owned fields.
- Sensitive changes should create audit records.
- Public users can only read published, non-deleted records.
- Contact details respect visibility settings.
- Media-kit private URLs should use signed access.
- Store share tokens as hashes.
