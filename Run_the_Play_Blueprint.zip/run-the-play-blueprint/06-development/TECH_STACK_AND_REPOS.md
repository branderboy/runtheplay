# Tech Stack and Open-Source Repositories

## Recommended stack

### Application

- Next.js with App Router
- React
- TypeScript
- Tailwind CSS
- shadcn/ui components

### Data

- Neon PostgreSQL
- Drizzle ORM
- PostgreSQL full-text search for MVP
- Optional Meilisearch or Typesense when search requirements outgrow PostgreSQL

### Authentication

- Better Auth for an open-source-first option
- Clerk as a faster hosted alternative

### Content

- Sanity for editorial flexibility, or
- Payload CMS for a self-hosted, open-source-first architecture

Choose one CMS rather than operating two content systems.

### Storage

- Cloudflare R2 or S3-compatible storage

### Email

- Resend

### Billing

- Stripe subscriptions

### Analytics

- PostHog for product behavior
- Plausible for lightweight web analytics

### Hosting

- Vercel

### Validation and forms

- Zod
- React Hook Form

### Testing

- Vitest
- React Testing Library
- Playwright

### Observability

- Sentry or an open-source alternative

## Architecture principles

- Begin as a modular monolith.
- Keep the recommendation engine deterministic and versioned.
- Store source provenance for imported data.
- Separate public profile data from private account and billing data.
- Use background jobs for imports, freshness checks, and email.
- Do not add a separate search service until PostgreSQL becomes a measurable limitation.

## Useful repositories and projects to evaluate

### UI and application patterns

- `shadcn-ui/ui` - component source and patterns
- `shadcn-ui/taxonomy` - older Next.js commerce/content architecture reference; evaluate rather than copy blindly
- `vercel/next.js` - framework examples and official source

### Database and ORM

- `drizzle-team/drizzle-orm`
- `neondatabase/serverless`

### Authentication

- `better-auth/better-auth`

### CMS

- `payloadcms/payload`
- `directus/directus` as an alternative data platform to evaluate

### Search

- `meilisearch/meilisearch`
- `typesense/typesense`

### Data fetching and tables

- `TanStack/query`
- `TanStack/table`

### Jobs and workflows

- `triggerdotdev/trigger.dev`
- `inngest/inngest`

### Analytics

- `PostHog/posthog`
- `plausible/analytics`

## Repository selection rules

Before adopting a repository, verify:

- License compatibility
- Recent maintenance activity
- Security posture
- Framework compatibility
- Deployment requirements
- Migration path
- Community and documentation quality

Do not treat a starter repository as the product architecture. Use it to accelerate setup while keeping the domain model and product logic original.

## Suggested MVP implementation

- Next.js + TypeScript
- Tailwind + shadcn/ui
- Neon + Drizzle
- Better Auth or Clerk
- Payload or Sanity
- PostgreSQL search
- Stripe
- Resend
- PostHog
- Vercel

## Environments

- Local
- Preview per pull request
- Staging
- Production

## Required engineering documentation

- Environment variable reference
- Migration process
- Seed-data process
- Import and deduplication process
- Data provenance rules
- Permission matrix
- Backup and restore plan
- Analytics event dictionary
- Recommendation algorithm version notes
