# Run the Play

**Advertising Made Simple for the Culture**

Run the Play is a discovery and planning platform for hip-hop podcast advertising. Podcasts can claim profiles and publish their available inventory. Brands, agencies, artists, entrepreneurs, local businesses, event promoters, nonprofits, and everyday people can build an ad plan around a budget, audience, goal, geography, and preferred ad formats.

Run the Play does not sell, broker, negotiate, or collect payment for podcast advertising. It helps people discover opportunities, organize a plan, and contact podcasts directly.

## Product entry point

The primary entry point is the **Ad Planner**, not the directory.

1. Define the campaign goal.
2. Enter a budget.
3. Identify the audience.
4. Select geography and channels.
5. Receive matching opportunities.
6. Add opportunities to a Campaign Basket.
7. Save, share, export, or contact podcasts directly.

## Documentation map

- `00-thesis/PRODUCT_THESIS.md`
- `01-research/PODCAST_RESEARCH_BRIEF.md`
- `01-research/COMPETITOR_RESEARCH_BRIEF.md`
- `02-product/PROJECT_BRIEF.md`
- `02-product/FEATURE_SPECIFICATION.md`
- `03-design/DESIGN_BRIEF.md`
- `04-data/DATABASE_SCHEMA.md`
- `05-content-seo/CONTENT_AND_SEO_STRATEGY.md`
- `06-development/TECH_STACK_AND_REPOS.md`
- `07-roadmap/DEVELOPMENT_ROADMAP.md`
- `templates/PODCAST_RESEARCH_TEMPLATE.csv`
- `templates/USER_INTERVIEW_GUIDE.md`

## North-star outcome

A user should be able to arrive with a message and a budget, then leave with a practical basket of culturally relevant podcast advertising opportunities.
