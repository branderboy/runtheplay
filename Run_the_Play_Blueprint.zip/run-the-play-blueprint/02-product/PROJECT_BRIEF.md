# Project Brief

## Project

Run the Play

## Tagline

Advertising Made Simple for the Culture

## Product summary

Run the Play is a claimable directory and advertising planning platform focused initially on hip-hop podcasts. The product lets users create a podcast ad plan based on budget, audience, goal, geography, timeline, and desired formats. Recommendations can be added to a Campaign Basket, saved, compared, shared, exported, and used to contact podcasts directly.

## Business objective

Create a low-cost subscription product for podcast owners while building a free, useful planning experience for buyers.

## User objective

### Buyer

Turn an unclear advertising idea into an organized set of relevant podcast opportunities.

### Podcast owner

Control how the show is represented, publish current inventory, and become easier for qualified buyers to discover.

## MVP goals

- Make the Ad Planner the primary homepage action.
- Launch with a useful seed database of hip-hop podcasts.
- Allow podcast owners to claim and update profiles.
- Allow claimed podcasts to add structured inventory.
- Let buyers save opportunities in a Campaign Basket.
- Generate recommendations using transparent rule-based matching.
- Provide direct inquiry and outbound contact links.
- Publish Clutch-style category pages and buyer guides.
- Support a $10-$20 monthly subscription test.

## Non-goals for MVP

- Selling or brokering advertising
- Negotiating rates
- Collecting campaign payments
- Guaranteeing performance
- Automated insertion orders or contracts
- Full attribution or ad-serving technology
- Public reviews
- An AI-only recommendation engine
- A marketplace checkout

## Primary personas

### First-time buyer

Has a goal and a limited budget but does not understand podcast inventory. Needs guidance and clear language.

### Experienced marketer

Knows the audience and campaign format. Needs filters, comparisons, shareable plans, and reliable data.

### Artist or event promoter

Needs to promote a release, show, tour, or event. Often has a specific geography and deadline.

### Independent podcast owner

Needs a professional profile and a simple way to publish inventory without building a separate sales site.

### Podcast network operator

Needs to manage multiple shows and make the network's available opportunities discoverable.

## Core user journey

1. User selects “Build an Ad Plan.”
2. User identifies the campaign goal.
3. User enters a budget or budget range.
4. User identifies the target audience.
5. User selects geography, timeline, and preferred formats.
6. Product presents matching podcast opportunities.
7. User adds opportunities to a Campaign Basket.
8. Product displays total planned spend, remaining budget, known audience indicators, and missing data warnings.
9. User saves, shares, or exports the plan.
10. User contacts selected podcasts directly.

## MVP modules

### Public

- Homepage and Ad Planner entry
- Planner wizard
- Recommendation results
- Podcast directory
- Podcast profiles
- Category pages
- Buyer guides
- Claim-profile page
- Pricing page

### Buyer account

- Saved plans
- Campaign Baskets
- Saved podcasts
- Notes
- Share links
- PDF/CSV export

### Podcast account

- Claim and verification
- Profile editor
- Inventory manager
- Audience and platform data
- Media kit upload or link
- Contact preferences
- Basic analytics
- Billing

### Administration

- Podcast import and moderation
- Claim review
- Taxonomy management
- Inventory type management
- Content publishing
- Data quality review
- Subscription administration

## Recommendation logic for MVP

Use a rules-based score rather than opaque AI.

Example score inputs:

- Audience fit
- Geography fit
- Goal fit
- Format fit
- Budget compatibility
- Inventory availability
- Profile freshness
- Verification status
- Data completeness

Recommendations must explain why each opportunity matched.

## Monetization

### Free listing

Basic profile created from public information.

### Claimed plan

Target test price: $10/month.

### Inventory plan

Target test price: $20/month.

### Future optional revenue

- Featured placement clearly labeled as sponsored
- Network accounts
- Data exports or professional research tools
- Premium buyer collaboration features

Run the Play should not take a commission on ad deals under the current thesis.

## Success criteria for initial launch

- At least 100 quality seed profiles
- At least 25 claimed profiles
- At least 15 profiles with active inventory
- At least 100 completed ad plans
- At least 25% of completed plans create a basket
- At least 10% of baskets trigger a direct-contact action
- At least 10 paying podcast accounts, as an early validation threshold

These are learning targets, not forecasts.

## Risks

- Podcast data becomes stale.
- Owners may not want to publish prices.
- Audience metrics may be inconsistent or unverifiable.
- A small inventory database can produce weak plans.
- Buyers may expect Run the Play to broker deals.
- Paid placement can reduce trust unless clearly labeled.
- Programmatic SEO can create thin pages if launched before data quality is strong.

## Risk controls

- Display “last updated” dates.
- Allow “contact for pricing.”
- Label data source and verification state.
- Begin with curated profiles rather than mass-generated pages.
- Use clear disclaimers around contact, pricing, availability, and performance.
- Require minimum data thresholds before indexing category pages.
