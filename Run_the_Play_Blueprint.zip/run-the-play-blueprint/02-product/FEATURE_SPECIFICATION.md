# Feature Specification

## 1. Ad Planner

### Purpose

Turn a user's campaign intent into a useful, explainable set of podcast opportunities.

### Entry points

- Homepage hero
- Main navigation
- Podcast profile CTA
- Buyer guide CTA
- Category page CTA

### Planner steps

#### Step 1: Campaign

Fields:

- Campaign name, optional for guests
- Organization or creator name, optional
- Campaign goal, required
- Short message or offer description, optional

Goal options:

- Brand awareness
- Product launch
- Music release
- Event promotion
- Local business promotion
- Lead generation
- Community or nonprofit message
- Recruiting
- Political or advocacy, subject to policy
- Other

#### Step 2: Budget

Fields:

- Exact budget or range
- Currency
- Whether production costs must fit inside the budget
- Minimum and maximum number of placements, optional

Rules:

- Budget must be greater than zero.
- The planner must not imply that listed prices are final.
- Opportunities with unknown prices can be shown separately.

#### Step 3: Audience

Fields:

- Age ranges
- Gender targeting, optional
- Interests
- Occupation or life stage
- Culture and community interests
- Desired audience size or intimacy preference

Examples:

- Hip-hop fans
- Independent artists
- Entrepreneurs
- Sneaker and fashion consumers
- Sports fans
- Music industry professionals
- Gen Z
- Millennials
- Local DMV audience

#### Step 4: Geography

Fields:

- National
- Regional
- State
- Metro area
- City
- No geographic preference

#### Step 5: Formats and timing

Formats:

- Host-read ad
- Pre-roll
- Mid-roll
- Post-roll
- Sponsored segment
- Sponsored episode
- Interview or guest opportunity, when offered
- Video integration
- Social clip
- Newsletter
- Live-event sponsorship

Timing:

- Start date
- End date
- Deadline flexibility

#### Step 6: Results

Each result card must show:

- Podcast name and artwork
- Match score or match label
- Why it matched
- Audience tags
- Geography
- Available formats
- Price or “contact for pricing”
- Verification and freshness state
- Add to Basket
- View profile

### Recommendation behavior

- Use only podcasts meeting hard filters.
- Rank remaining results using weighted rules.
- Diversify recommendations when possible instead of returning near-identical shows.
- Explain the strongest matching factors.
- Flag missing or self-reported data.
- Do not fabricate reach, price, availability, or demographic data.

### Guest behavior

A guest can complete the planner and build a temporary basket. An account is required to save permanently, share privately, or return later.

### Empty state

When no exact matches exist:

- Explain which constraint reduced results.
- Offer adjacent opportunities.
- Let the user relax one filter at a time.

## 2. Campaign Basket

### Purpose

Organize selected opportunities into a practical campaign plan.

### Core capabilities

- Add and remove opportunities
- Select inventory item and quantity
- Adjust provisional price when the profile allows custom budgeting
- Add notes
- Reorder items
- Group by channel, audience, geography, or campaign stage
- Display planned spend
- Display remaining budget
- Display items with unknown pricing separately
- Save multiple versions
- Duplicate a basket
- Share a read-only link
- Export PDF or CSV
- Open direct-contact links

### Budget behavior

Basket totals must distinguish:

- Known listed price
- Starting price
- User-entered estimate
- Unknown/contact-for-pricing

The interface must never present an estimated basket as a confirmed media buy.

### Share behavior

- Private by default
- Share link can be revoked
- Owner controls whether notes appear
- No personal contact data should appear without consent

## 3. Podcast Directory

### Search

- Podcast name
- Host name
- Network
- Topic
- Audience tag
- Geography

### Filters

- Claimed
- Verified
- Inventory available
- Price range
- Ad format
- Video or audio
- Publishing frequency
- Geography
- Audience interests
- Network or independent
- Last updated

### Sorting

- Best match
- Recently updated
- Alphabetical
- Newly added
- Price, only where comparable

Paid placement must never silently replace relevance ranking.

## 4. Podcast Profile

### Public sections

- Overview
- Hosts and network
- Platforms
- Topics and audience
- Advertising opportunities
- Pricing state
- Media kit
- Contact method
- Recent episodes or clips, optional
- Verification and last-updated information
- Similar podcasts

### Data labels

Every important metric should be labeled as one of:

- Verified by Run the Play
- Owner provided
- Public source
- Estimated
- Not provided

## 5. Claim Profile

### Claim methods

- Email at the podcast's official domain
- Verification code placed in an RSS feed or website
- Social-account confirmation
- Manual documentation review

### Workflow

1. User selects “Claim this profile.”
2. User creates an account.
3. User identifies their role.
4. User selects a verification method.
5. Claim enters pending review.
6. Admin approves, rejects, or requests more information.
7. Approved claimant receives profile permissions.

### Conflicts

Multiple people may request access. Support roles and ownership hierarchy rather than assuming one permanent owner.

## 6. Profile Editor

Editable fields:

- Name
- Description
- Artwork
- Website
- RSS feed
- Hosts
- Network
- Location
- Categories
- Audience tags
- Platforms
- Publishing schedule
- Contact preferences
- Media kit
- Audience data

Changes to sensitive or identity fields may require moderation.

## 7. Inventory Manager

Fields per inventory item:

- Inventory type
- Name
- Description
- Placement details
- Audio, video, social, email, or event channel
- Price type
- Price or starting price
- Currency
- Unit, such as episode, week, clip, or package
- Availability state
- Lead time
- Audience notes
- Creative requirements
- Restrictions
- Contact CTA
- Last confirmed date

Price types:

- Fixed
- Starting at
- Range
- Contact for pricing
- Not currently available

## 8. Saved Search and Alerts

Post-MVP feature.

Users can save planner criteria and receive alerts when:

- A matching podcast is added
- Relevant inventory becomes available
- A profile updates pricing

## 9. Analytics

### Podcast analytics

- Profile views
- Planner appearances
- Basket adds
- Contact clicks
- Media-kit clicks
- Source pages

### Buyer analytics

- Plan completion
- Basket creation
- Export and share actions
- Contact clicks

Analytics must be aggregate and privacy-aware.

## 10. Administration

- Import podcasts
- Merge duplicates
- Edit source records
- Review claims
- Moderate changes
- Manage taxonomy
- Manage category pages
- Flag stale profiles
- Manage subscriptions
- View data-quality reports
- Audit key actions
