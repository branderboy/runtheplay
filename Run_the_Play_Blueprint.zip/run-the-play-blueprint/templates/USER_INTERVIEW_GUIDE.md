# User Interview Guide

## Buyer interview

1. Tell me about the last time you tried to promote a product, event, release, or message through a podcast.
2. How did you find the shows?
3. What information was hardest to get?
4. Did you begin with a budget, an audience, or a specific podcast?
5. How did you compare options?
6. What made you trust or reject an opportunity?
7. What did you need to share with a client or partner?
8. Would a saved campaign basket be useful? Why?
9. Which parts should be free?
10. What would make you return?

## Podcast-owner interview

1. How do advertisers currently discover you?
2. Where is your advertising information stored?
3. Which inventory do you offer?
4. Do you publish rates? Why or why not?
5. What makes an inquiry qualified?
6. Would you claim and update a public profile?
7. What would make $10 or $20 per month worthwhile?
8. Which analytics matter?
9. What information should never be public?
10. How often could you realistically confirm inventory?

## Interview rules

- Ask about real past behavior before asking about hypothetical features.
- Do not pitch throughout the interview.
- Capture exact language users use.
- Separate buyer and podcast-owner findings.
